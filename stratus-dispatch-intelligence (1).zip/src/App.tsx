import React, { useState, useEffect, useMemo } from 'react';
import { Load, Assumptions, ScoredLoad, OptimizedChain } from './types';
import { DEFAULT_ASSUMPTIONS } from './constants';
import { generateRandomLoads } from './utils/generator';
import { scoreLoad, calculateDistance } from './utils/math';
import { optimizeChain, naiveBaseline } from './utils/optimizer';

import ControlBar from './components/ControlBar';
import AssumptionsPanel from './components/AssumptionsPanel';
import OptimizedChainView from './components/OptimizedChainView';
import ComparisonView from './components/ComparisonView';
import LoadPoolTable from './components/LoadPoolTable';
import AddLoadModal from './components/AddLoadModal';

export default function App() {
  // State
  const [loads, setLoads] = useState<Load[]>([]);
  const [assumptions, setAssumptions] = useState<Assumptions>(DEFAULT_ASSUMPTIONS);
  const [truckLocation, setTruckLocation] = useState('Cleveland, OH');
  const [hosRemaining, setHosRemaining] = useState(11);
  const [isAssumptionsOpen, setIsAssumptionsOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  
  const [optimizedChain, setOptimizedChain] = useState<OptimizedChain | null>(null);
  const [naiveChain, setNaiveChain] = useState<OptimizedChain | null>(null);
  const [manualChainIds, setManualChainIds] = useState<string[]>([]);

  // Initial Load Generation
  useEffect(() => {
    setLoads(generateRandomLoads(50));
  }, []);

  // Calculate Scored Loads
  const scoredLoads = useMemo(() => {
    return loads.map(load => {
      const dh = calculateDistance(truckLocation, load.origin);
      return scoreLoad(load, dh, assumptions);
    });
  }, [loads, truckLocation, assumptions]);

  // Run Optimizer
  const handleRunOptimizer = () => {
    const optimized = optimizeChain(loads, truckLocation, hosRemaining, assumptions);
    const naive = naiveBaseline(loads, truckLocation, hosRemaining, assumptions);
    
    setOptimizedChain(optimized);
    setNaiveChain(naive);
    setManualChainIds(optimized.legs.filter(l => l.load).map(l => l.load!.id));
  };

  // Manual Override
  const handleToggleLoad = (id: string) => {
    let newIds: string[];
    if (manualChainIds.includes(id)) {
      newIds = manualChainIds.filter(i => i !== id);
    } else {
      newIds = [...manualChainIds, id];
    }
    setManualChainIds(newIds);
    
    // Recalculate chain based on manual selection
    recalculateManualChain(newIds);
  };

  const recalculateManualChain = (ids: string[]) => {
    const selectedLoads = loads.filter(l => ids.includes(l.id));
    
    let currentCity = truckLocation;
    let currentMiles = 0;
    const legs: any[] = [];
    let remaining = [...selectedLoads];
    let currentTime = new Date();
    currentTime.setHours(8, 0, 0, 0);

    while (remaining.length > 0) {
      // Find closest next load
      remaining.sort((a, b) => calculateDistance(currentCity, a.origin) - calculateDistance(currentCity, b.origin));
      const next = remaining.shift()!;
      const dh = calculateDistance(currentCity, next.origin);
      const result = scoreLoad(next, dh, assumptions);
      
      const legStartTime = new Date(Math.max(currentTime.getTime(), new Date(next.pickupWindowStart).getTime()));
      const legEndTime = new Date(legStartTime.getTime() + result.totalHours * 3600000);
      const isOvernight = result.totalHours > 10 || (legEndTime.getHours() < legStartTime.getHours());

      legs.push({ 
        load: next, 
        deadhead: dh, 
        result,
        startTime: legStartTime.toISOString(),
        endTime: legEndTime.toISOString(),
        isOvernight
      });
      currentCity = next.destination;
      currentMiles += dh + next.miles;
      currentTime = legEndTime;
    }

    // Add return home leg if needed
    if (currentCity !== assumptions.homeBase) {
      const dhToHome = calculateDistance(currentCity, assumptions.homeBase);
      const driveTime = dhToHome / assumptions.avgSpeed;
      const endTime = new Date(currentTime.getTime() + driveTime * 3600000);
      
      const fuelCpm = assumptions.fuelPrice / assumptions.mpg;
      const totalCpm = fuelCpm + assumptions.driverPay + assumptions.truckLease + assumptions.insurance + assumptions.maintReserve + assumptions.overhead;
      const cost = dhToHome * totalCpm;

      legs.push({
        load: null,
        deadhead: dhToHome,
        result: {
          id: 'RETURN-HOME',
          origin: currentCity,
          destination: assumptions.homeBase,
          miles: 0,
          rate: 0,
          weight: 0,
          commodity: 'DEADHEAD',
          detentionHours: 0,
          pickupWindowStart: currentTime.toISOString(),
          deliveryDeadline: endTime.toISOString(),
          deadheadMiles: dhToHome,
          totalMiles: dhToHome,
          totalCost: cost,
          netRevenue: 0,
          profit: -cost,
          marginPct: -100,
          rpm: 0,
          allInRpm: 0,
          driveHours: driveTime,
          totalHours: driveTime,
          profitPerHour: -totalCpm * assumptions.avgSpeed,
          score: -5,
          action: 'PASS',
          estimatedDelivery: endTime.toISOString()
        },
        startTime: currentTime.toISOString(),
        endTime: endTime.toISOString(),
        isOvernight: false,
        isReturnHome: true
      });
    }

    // Update the optimized chain view with manual results
    const summary = summarizeLegs(legs);
    setOptimizedChain({ legs, summary });
  };

  const summarizeLegs = (legs: any[]) => {
    const totalProfit = legs.reduce((sum, l) => sum + (l.result?.profit || 0), 0);
    const totalRevenue = legs.reduce((sum, l) => sum + (l.result?.netRevenue || 0), 0);
    const totalDeadhead = legs.reduce((sum, l) => sum + l.deadhead, 0);
    const totalMiles = legs.reduce((sum, l) => sum + (l.result?.totalMiles || 0), 0);
    const totalHours = legs.reduce((sum, l) => sum + (l.result?.totalHours || 0), 0);
    const avgMargin = legs.filter(l => !l.isReturnHome).length > 0 
      ? legs.filter(l => !l.isReturnHome).reduce((sum, l) => sum + (l.result?.marginPct || 0), 0) / legs.filter(l => !l.isReturnHome).length 
      : 0;

    return {
      totalProfit,
      totalRevenue,
      numLoads: legs.filter(l => !l.isReturnHome).length,
      totalDeadhead,
      deadheadPct: totalMiles > 0 ? (totalDeadhead / totalMiles) * 100 : 0,
      totalHours,
      avgMargin,
      profitPerHour: totalHours > 0 ? totalProfit / totalHours : 0,
      totalMiles
    };
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-amber-500/30">
      <ControlBar 
        truckLocation={truckLocation}
        setTruckLocation={setTruckLocation}
        hosRemaining={hosRemaining}
        setHosRemaining={setHosRemaining}
        daysAway={assumptions.daysAway}
        setDaysAway={(d) => setAssumptions(prev => ({ ...prev, daysAway: d }))}
        homeBase={assumptions.homeBase}
        setHomeBase={(h) => setAssumptions(prev => ({ ...prev, homeBase: h }))}
        onRunOptimizer={handleRunOptimizer}
        onAddLoad={() => setIsAddModalOpen(true)}
        onGenerateLoads={() => setLoads(generateRandomLoads(50))}
      />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <AssumptionsPanel 
          assumptions={assumptions}
          setAssumptions={setAssumptions}
          isOpen={isAssumptionsOpen}
          setIsOpen={setIsAssumptionsOpen}
        />

        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black text-white uppercase tracking-tight font-display">Optimized Dispatch Chain</h2>
            {optimizedChain && (
              <button 
                onClick={() => { setOptimizedChain(null); setNaiveChain(null); setManualChainIds([]); }}
                className="text-xs font-bold text-slate-500 hover:text-white uppercase tracking-widest transition-colors"
              >
                Clear Results
              </button>
            )}
          </div>
          <OptimizedChainView chain={optimizedChain} assumptions={assumptions} />
        </div>

        <ComparisonView optimized={optimizedChain} naive={naiveChain} />

        <div className="mb-20">
          <LoadPoolTable 
            loads={scoredLoads} 
            includedInChain={manualChainIds}
            onToggleLoad={handleToggleLoad}
          />
        </div>
      </main>

      <AddLoadModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onAdd={(load) => setLoads([load, ...loads])} 
      />

      {/* Footer / Branding */}
      <footer className="border-t border-slate-900 py-12 px-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-6 h-6 bg-slate-800 rounded flex items-center justify-center">
            <span className="text-[10px] font-black text-white">S</span>
          </div>
          <span className="text-sm font-bold text-slate-600 uppercase tracking-[0.3em]">Stratus Logistics LLC</span>
        </div>
        <p className="text-xs text-slate-700">© 2026 Stratus Dispatch Intelligence. All rights reserved.</p>
      </footer>
    </div>
  );
}
